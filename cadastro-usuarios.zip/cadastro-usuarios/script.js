let db;

const request = indexedDB.open("MeuBanco", 1);

request.onupgradeneeded = function (event) {
  db = event.target.result;
  db.createObjectStore("usuarios", { keyPath: "id", autoIncrement: true });
};

request.onsuccess = function (event) {
  db = event.target.result;
  listarUsuarios();
};

document.getElementById("userForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const nome = document.getElementById("name").value;
  const email = document.getElementById("email").value;

  const transaction = db.transaction(["usuarios"], "readwrite");
  const store = transaction.objectStore("usuarios");

  const usuario = { nome, email };
  store.add(usuario);

  transaction.oncomplete = () => {
    document.getElementById("userForm").reset();
    listarUsuarios();
  };
});

function listarUsuarios() {
  const transaction = db.transaction(["usuarios"], "readonly");
  const store = transaction.objectStore("usuarios");
  const request = store.openCursor();
  const userList = document.getElementById("userList");
  userList.innerHTML = "";

  request.onsuccess = function (event) {
    const cursor = event.target.result;
    if (cursor) {
      const { id, nome, email } = cursor.value;
      const li = document.createElement("li");
      li.innerHTML = `
        <strong>${nome}</strong> (${email})<br>
        <button onclick="editarUsuario(${id})">Editar</button>
        <button onclick="excluirUsuario(${id})">Excluir</button>
      `;
      userList.appendChild(li);
      cursor.continue();
    }
  };
}

function excluirUsuario(id) {
  const transaction = db.transaction(["usuarios"], "readwrite");
  const store = transaction.objectStore("usuarios");
  store.delete(id);
  transaction.oncomplete = listarUsuarios;
}

function editarUsuario(id) {
  const transaction = db.transaction(["usuarios"], "readonly");
  const store = transaction.objectStore("usuarios");
  const request = store.get(id);

  request.onsuccess = function () {
    const usuario = request.result;
    document.getElementById("name").value = usuario.nome;
    document.getElementById("email").value = usuario.email;

    excluirUsuario(id); // Remove o antigo para salvar como novo
  };
}
